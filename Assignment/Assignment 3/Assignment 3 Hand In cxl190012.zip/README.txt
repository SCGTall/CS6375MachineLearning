Despite that the help video asks us to submit four python files, most of code are replicating. So I write a public library: Assignment 3.py to help manipulate the whole project. Remember to keep it in the root directory.

Four separately python files:
NaiveBayes.py
NaiveBayesWithoutSW.py
LogisticRegression.py
LogisticRegressionWithoutSW.py
Just run these four python files without extra parameter. For LogisticRegression.py and LogisticRegressionWithoutSW.py, the hard limit, learning rate and lambda list([0.01, 0.02, 0.05, 0.1]) are hardly code in file. You can adjust it if necessary.

All stop words are stored in stopwords.txt.
Remember that the train/, test/, stopwords.txt should also be kept in the root directory.
Just simply run Assignment5.py in IDE or command line. 
You should keep Assignment5.py, Koala.jpg and Penguins.jpg in the same directory. The results will generate in the same folder.